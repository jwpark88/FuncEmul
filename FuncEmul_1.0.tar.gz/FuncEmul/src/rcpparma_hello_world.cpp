// -*- mode: C++; c-indent-level: 4; c-basic-offset: 4; indent-tabs-mode: nil; -*-

// we only include RcppArmadillo.h which pulls Rcpp.h in for us
// [[Rcpp::depends("RcppArmadillo")]]

#include <RcppArmadillo.h>
#include <limits>
#include <omp.h>
#define min(x,y) (((x) < (y)) ? (x) : (y))

using namespace std;
using namespace Rcpp;
using namespace arma;




// [[Rcpp::export]]
double Choose(int x, int y){
	double result1 = 1, result2 = 1, result;
	int iter = y;
	
    if( x< y ){ result = 0;	}else{	
    for(int i = 0; i<iter; i++){
    	result1 = result1*x;
    	result2 = result2*y;
    	y = y-1;
    	x = x-1;   	
	}	
    	
    	
    result = result1/result2;
	}
return(result);
}



// [[Rcpp::export]]
vec countShared(vec rowsum, mat X){
	
	int numedges = sum(rowsum)/2, nrow = rowsum.n_elem ,ind;
	vec hist = zeros(numedges);
	int num = 0;
	for(int k = 0; k< nrow; k++){
        for(int j = 0; j< k+1; j++){
	        if( X(k,j) == 1){  for(int i = 0; i<nrow; i++){ hist(num) =  hist(num) + X(i,k)*X(k,j)*X(j,i); }
            num = num + 1; }
				            
		}
    }
	vec shared = zeros(nrow);
	for(int i = 0; i < numedges; i++ ){
	ind = hist(i);	
	if(ind>0){ shared(ind-1) = shared(ind-1) + 1; }
    }
	return(shared);
}



// [[Rcpp::export]]
vec Summary(mat X){
	int nrow = X.n_rows;
    double decay = 0.25;
	vec rowsum = sum(X,1), result = zeros(2);
    

    vec shared = countShared(rowsum,X);
    

    for(int i = 0; i< nrow; i++){
	result(0) = result(0) + Choose(rowsum(i),1);
	result(1) = result(1) + (   1- pow( (1-exp(-decay)),i+1)  )*shared(i);   
    }
    
    result(0)=result(0)/2;
   	result(1)=exp(decay)*result(1);   
    	 
return result;
}



// [[Rcpp::export]]
vec Gibbs(mat X, vec coef, int cycle){
int nrow = X.n_rows,indi,indj,prei,prej,res;
double decay = 0.25;
vec star = sum(X,1), changestat = zeros(2), Sumstat = Summary(X) ;
rowvec ivec = trans( zeros(nrow) ), jvec = trans( zeros(nrow) );
vec geoweight = zeros(nrow);
for(int i =0; i<nrow; i++){ geoweight(i) = 1- pow( (1-exp(-decay)),i+1); }


    for(int l = 0; l< cycle; l++){
    for(int i = 1; i< nrow; i++){
    for(int j = 0; j< i; j++){
         ivec(i) = 1; jvec(j) = 1;
		 res = 0; 
         	

         if(X(i,j)==0){  
           indi = star(i) + 1, indj = star(j) + 1; 

		   changestat(0) = ( Choose(indi,1) + Choose(indj,1) - Choose(star(i),1) - Choose(star(j),1) )/2;
		               

		   changestat(1) = 0;     
           for(int k = 0; k< nrow; k++){
           if(   ( X(i,k) == 1 ) & ( X(j,k) == 1  )   ){
		   prei = sum( X.row(i)%X.row(k) );
   		   prej = sum( X.row(j)%X.row(k) );

   		   changestat(1) = changestat(1) + exp(decay)*geoweight(prei+1-1) ; 
		   if(prei >0){ changestat(1) = changestat(1) - exp(decay)*geoweight(prei-1);} 
 		   changestat(1) = changestat(1) + exp(decay)*geoweight(prej+1-1) ; 
		   if(prej >0){ changestat(1) = changestat(1) - exp(decay)*geoweight(prej-1);} 
           res = res + 1; 
           }
           }
           if(res > 0){ changestat(1) = changestat(1) + exp(decay)*geoweight(res-1); }
     

           vec r =  exp(trans(coef)*changestat) ;         
           double p = r(0)/(1+r(0));   		   
		   if( randu() < p  ){
		   X(i,j) = X(j,i) = 1; 
		   star(i) = indi; star(j) = indj;		 
		   Sumstat = Sumstat + changestat;
		   }
		   
 
         }else{
           indi = star(i) - 1, indj = star(j) - 1;	

           changestat(0) = ( Choose(star(i),1) + Choose(star(j),1) - Choose(indi,1) - Choose(indj,1) )/2;
		   		   		        

           changestat(1) = 0;
           for(int k = 0; k< nrow; k++){
           if(   ( X(i,k) == 1 ) & ( X(j,k) == 1  )   ){
		   prei = sum( X.row(i)%X.row(k) );
   		   prej = sum( X.row(j)%X.row(k) );
   		   if(prei-1 >0){changestat(1) = changestat(1) - exp(decay)*geoweight(prei-1-1); } 
			changestat(1) = changestat(1) + exp(decay)*geoweight(prei-1); 
 		   if(prej-1 >0){changestat(1) = changestat(1) - exp(decay)*geoweight(prej-1-1); } 
			changestat(1) = changestat(1) + exp(decay)*geoweight(prej-1); 
           res = res + 1; 
           }
           }
           if(res > 0){ changestat(1) = changestat(1) + exp(decay)*geoweight(res-1); }
		   

           vec r =  exp(trans(coef)*changestat) ;         
           double p = r(0)/(1+r(0));   		   
		   if( randu() > p  ){
		   X(i,j) = X(j,i) = 0; 
		   star(i) = indi; star(j) = indj;  
		   Sumstat = Sumstat - changestat;
		   }             
         }
 
        ivec(i) = 0; jvec(j) = 0;
    }
    }   
    }
 
return(Sumstat); 
}



// [[Rcpp::export]]
mat Gibbs2(mat X, vec coef, int cycle){
int nrow = X.n_rows,indi,indj,prei,prej,res;
double decay = 0.25;
vec star = sum(X,1), changestat = zeros(2), Sumstat = Summary(X) ;
rowvec ivec = trans( zeros(nrow) ), jvec = trans( zeros(nrow) );
vec geoweight = zeros(nrow);
for(int i =0; i<nrow; i++){ geoweight(i) = 1- pow( (1-exp(-decay)),i+1); }


    for(int l = 0; l< cycle; l++){
    for(int i = 1; i< nrow; i++){
    for(int j = 0; j< i; j++){
         ivec(i) = 1; jvec(j) = 1;
		 res = 0; 
         	

         if(X(i,j)==0){  
           indi = star(i) + 1, indj = star(j) + 1; 

		   changestat(0) = ( Choose(indi,1) + Choose(indj,1) - Choose(star(i),1) - Choose(star(j),1) )/2;

		   changestat(1) = 0;     
           for(int k = 0; k< nrow; k++){
           if(   ( X(i,k) == 1 ) & ( X(j,k) == 1  )   ){
		   prei = sum( X.row(i)%X.row(k) );
   		   prej = sum( X.row(j)%X.row(k) );

   		   changestat(1) = changestat(1) + exp(decay)*geoweight(prei+1-1) ; 
		   if(prei >0){ changestat(1) = changestat(1) - exp(decay)*geoweight(prei-1);} 
 		   changestat(1) = changestat(1) + exp(decay)*geoweight(prej+1-1) ; 
		   if(prej >0){ changestat(1) = changestat(1) - exp(decay)*geoweight(prej-1);} 
           res = res + 1; 
           }
           }
           if(res > 0){ changestat(1) = changestat(1) + exp(decay)*geoweight(res-1); }
     

           vec r =  exp(trans(coef)*changestat) ;         
           double p = r(0)/(1+r(0));   		   
		   if( randu() < p  ){
		   X(i,j) = X(j,i) = 1; 
		   star(i) = indi; star(j) = indj;		 
		   Sumstat = Sumstat + changestat;
		   }
		   
		   

         }else{
           indi = star(i) - 1, indj = star(j) - 1;	

           changestat(0) = ( Choose(star(i),1) + Choose(star(j),1) - Choose(indi,1) - Choose(indj,1) )/2;
		   		   		        

           changestat(1) = 0;
           for(int k = 0; k< nrow; k++){
           if(   ( X(i,k) == 1 ) & ( X(j,k) == 1  )   ){
		   prei = sum( X.row(i)%X.row(k) );
   		   prej = sum( X.row(j)%X.row(k) );
   		   if(prei-1 >0){changestat(1) = changestat(1) - exp(decay)*geoweight(prei-1-1); } 
			changestat(1) = changestat(1) + exp(decay)*geoweight(prei-1); 
 		   if(prej-1 >0){changestat(1) = changestat(1) - exp(decay)*geoweight(prej-1-1); } 
			changestat(1) = changestat(1) + exp(decay)*geoweight(prej-1); 
           res = res + 1; 
           }
           }
           if(res > 0){ changestat(1) = changestat(1) + exp(decay)*geoweight(res-1); }
		   

           vec r =  exp(trans(coef)*changestat) ;         
           double p = r(0)/(1+r(0));   		   
		   if( randu() > p  ){
		   X(i,j) = X(j,i) = 0; 
		   star(i) = indi; star(j) = indj;  
		   Sumstat = Sumstat - changestat;
		   }             
         }

        ivec(i) = 0; jvec(j) = 0;
    }
    }   
    }
 
return(X); 
}


// [[Rcpp::export]]
mat ergmDMH(mat X, mat COV, mat theta, int outer, int cycle){
	

double logprob,u;                        
int nCOVcols = COV.n_cols;                
vec thetaprev(nCOVcols);                  
vec stat = Summary(X), statprop(nCOVcols); 
     	

for(int l = 0; l< outer; l++){

	if( (l > 1000) && (l <= 10000) ){ 
	COV = cov(theta);
    }	

    for(int i = 0; i< nCOVcols; i++){
    	thetaprev[i] = theta(l,i);
    }
    
    vec Znormal = randn(nCOVcols);                                           
    vec thetaprop = trans(  trans(thetaprev) + trans(Znormal)*chol(COV)  );  

	
	statprop = Gibbs(X, thetaprop, cycle);
	
   
	vec dummy = ( -0.05*trans(thetaprop)*thetaprop + 0.05*trans(thetaprev)*thetaprev + trans(thetaprev - thetaprop)*(statprop - stat) );
	logprob = dummy[0];
    u = log( randu() );
    if( u< logprob ){
    theta.insert_rows(l+1,trans(thetaprop));
	}else{
	theta.insert_rows(l+1,trans(thetaprev));
	}
		
}
	
return(theta);	
}



// [[Rcpp::export]]
cube pAuxSamp(mat X, int cycle, mat Designmat, int m, int num){

int thnrow = Designmat.n_rows;            
cube H(thnrow,2,m);                       
omp_set_num_threads(num);



for(int M = 0; M < m; M++){            

        int i;
      #pragma omp parallel shared(Designmat) private(i)
      {	
      #pragma omp for schedule(static)  
    for(i = 0; i < thnrow; i++){
        vec thetaprop = trans( Designmat.row( i ) );        
        vec sumstat = Gibbs(X, thetaprop, cycle);
		
	for(int j = 0; j < 2; j++){ H(i,j,M) = sumstat[j];  }
		 	
        }
     }
}
return(H);        	
}


// [[Rcpp::export]]
mat pResponseErgm(mat X, int cycle, vec hatparameter, int m, int num){

mat H(m,2);                       
omp_set_num_threads(num);


int M;
#pragma omp parallel shared(H) private(M)
{	
#pragma omp for schedule(static)  
for(M = 0; M < m; M++){                           
   
    vec sumstat = Gibbs(X, hatparameter, cycle);  
    H(M,0) = sumstat[0];
    H(M,1) = sumstat[1];
}
}

return(H);        	
}




// [[Rcpp::export]]
mat GPmcmcErgm(int Niter, mat theta, mat COV, double lhXZ, vec betahat, vec phihat, mat Designmat, vec y, vec stat){
	int thnrow = Designmat.n_rows;                                                
	int nCOVcols = COV.n_cols;                                                    
	vec thetaprev(nCOVcols);                                                     
	
	double lhXZp,logprob,u;                                               
	double negativeInf = -std::numeric_limits<float>::infinity();;	               
	double phi1hat = phihat[0], phi2hat = phihat[1], sigmasqhat = phihat[2]; 
	

	int percentile = 0.0025*thnrow; 
	

	mat Domain(2,nCOVcols);                                                         
	for(int i = 0; i < nCOVcols; i++){
	vec dummy = sort( Designmat.col( i ) );
	Domain(0,i) = dummy(percentile);
	Domain(1,i) = dummy(thnrow-1-percentile);
    }
	
	mat h1(thnrow,thnrow), h2(thnrow,thnrow);   
    vec h1dcross(thnrow), h2dcross(thnrow);     
    
    for(int i = 0; i < thnrow; i++){
        for(int j = 0; j <= i; j++){
	        h1(i,j) = h1(j,i) = fabs(Designmat(i,0)-Designmat(j,0));
	        h2(i,j) = h2(j,i) = fabs(Designmat(i,1)-Designmat(j,1));
	    }
	}
	mat Sigma = sigmasqhat*(1+sqrt(3)*h1/phi1hat)%exp(-sqrt(3)*h1/phi1hat)%(1+sqrt(3)*h2/phi2hat)%exp(-sqrt(3)*h2/phi2hat);
	mat InvSigma = inv(Sigma);	   
	mat Xth = ones(thnrow,1);
    Xth.insert_cols(1,Designmat);	 
	
	

	for(int k = 0; k< Niter; k++){
	    if( (k > 1000) && (k <= 10000) ){ 
	    COV = cov(theta);
        }	
        vec Znormal = randn(nCOVcols);
    	for(int i = 0; i< nCOVcols; i++){
    		thetaprev[i] = theta(k,i);
		}
		

    	vec thetaprop = trans(  trans(thetaprev) + trans(Znormal)*chol(COV)  );
     

        if( thetaprop[0] > Domain(1,0) || thetaprop[0] < Domain(0,0) || thetaprop[1] > Domain(1,1) || thetaprop[1] < Domain(0,1) ){
		logprob = negativeInf;	
		
		}else{			
		for(int i = 0; i< thnrow; i++){  
    		h1dcross[i] =  fabs(thetaprop[0]-Designmat(i,0));
			h2dcross[i] =  fabs(thetaprop[1]-Designmat(i,1));	
		}
    	mat Sigmacross = sigmasqhat*(1+sqrt(3)*h1dcross/phi1hat)%exp(-sqrt(3)*h1dcross/phi1hat)%(1+sqrt(3)*h2dcross/phi2hat)%exp(-sqrt(3)*h2dcross/phi2hat);
    	vec xpoint = ones(1);
    	xpoint.insert_rows(1,thetaprop);
    	lhXZp = (trans(xpoint)*betahat + trans(Sigmacross)* InvSigma*(y-Xth*betahat))[0]; 
    
    	logprob = lhXZp - lhXZ;             
        } 

        u = log( randu() );
    	if( u< logprob ){
    	theta.insert_rows(k+1,trans(thetaprop));
		lhXZ = lhXZp;		
		}else{
	    theta.insert_rows(k+1,trans(thetaprev));
		}

   }
		
return theta;
}




// [[Rcpp::export]]
vec coeff(vec parameter){
	
vec r(2);
double lambda = parameter[0], t1 = parameter[1], t2 = parameter[2], t3 = parameter[3], R = 0; 
double a = (t2-R)*(t2-R)/(t1*t3*t3); 
double b = t3*t3*(t1 - 1);
double d = 27*a*b*b;
double c = pow(d + sqrt((d+2)*(d+2)-4) + 2,1.0/3.0); 
double deltar = 1/(3*b) * ( c/pow(2,1.0/3.0) + pow(2,1.0/3.0)/c + 1 );
r[0] = a / pow(deltar,1.5)+ t2;
r[1] = r[0] - sqrt(deltar);

return(r);	
}



// [[Rcpp::export]]
double evalunNormX(vec thetaprop, mat initialdist){
    int nrow = initialdist.n_rows; 
	double R = 0;
	

	vec rp = coeff(thetaprop);
    double r1p = rp[0], r2p = rp[1], lambdap= thetaprop[0], t1p = thetaprop[1], t2p = thetaprop[2], t3p = thetaprop[3];
   
     
    mat resultXp(nrow,nrow);    
	for(int i = 0; i < nrow; i++){
    for(int j = 0; j <= i; j++){
    	
        if(initialdist(i,j)>100){
        resultXp(i,j) = resultXp(j,i) = log(1);
        }else if ( (initialdist(i,j)>r1p) && (initialdist(i,j)<=100) ){
        resultXp(i,j) = resultXp(j,i) = log( 1 + 1/(t3p*t3p*(initialdist(i,j)-r2p)*(initialdist(i,j)-r2p)) );
        }else if ( (initialdist(i,j)>R) && (initialdist(i,j)<=r1p) ){
        resultXp(i,j) = resultXp(j,i) = log( t1p - (sqrt(t1p)*(initialdist(i,j)-t2p)/(t2p-R))*(sqrt(t1p)*(initialdist(i,j)-t2p)/(t2p-R)) );
        }else {
        resultXp(i,j) = resultXp(j,i) = 0;
        }
        }
    }  
    
    rowvec rhoXpsum = sum(resultXp);                    
    double lhXp = 0;
	for(int i = 0; i<nrow; i++){
    	lhXp = min(rhoXpsum[i],1.2) + lhXp;
        }
    lhXp = lhXp + (nrow)*log(lambdap);              

return(lhXp);    
}




// [[Rcpp::export]]
mat BDmcmc(vec center, double range, mat initial, mat initialdist, vec parameter, int n){
	

vec r = coeff(parameter);
double r1 = r[0], r2 = r[1], lambda= parameter[0], t1 = parameter[1], t2 = parameter[2], t3 = parameter[3], R = 0;
              
int nrow = initialdist.n_rows;       
mat result(nrow,nrow);               
rowvec rho0sum(nrow);                
rowvec xprop(2);                     
double logratio,logv;               

for(int i = 0; i < nrow; i++){
    for(int j = 0; j <= i; j++){
    	
        if(initialdist(i,j)>100){
        result(i,j) = result(j,i) = log(1);
        }else if ( (initialdist(i,j)>r1) && (initialdist(i,j)<=100) ){
        result(i,j) = result(j,i) = log( 1 + 1/(t3*t3*(initialdist(i,j)-r2)*(initialdist(i,j)-r2)) );
        }else if ( (initialdist(i,j)>R) && (initialdist(i,j)<=r1) ){
        result(i,j) = result(j,i) = log( t1 - (sqrt(t1)*(initialdist(i,j)-t2)/(t2-R))*(sqrt(t1)*(initialdist(i,j)-t2)/(t2-R)) );
        }
        
        }
    } 
        	
rho0sum = sum(result);                       
double distance;                                
double likelihood,likelihoodprev;           
mat loc = initial;                          

		
double p1 = 0.5, p2 = 0.5;    
for(int k = 0; k < n; k++){

    int count = loc.n_rows;
    likelihoodprev = 0; 
    for(int i = 0; i<count; i++){
  	    likelihoodprev = min(rho0sum[i],1.2) + likelihoodprev;   
   	    }  	
   	    
	double u = randu();
	if( u < p1 ){  

	double radius = sqrt(   pow((range),2)*randu()   );
	double t = 2*(M_PI)*randu();
	double xx = center[0]+radius*cos(t), yy = center[1]+radius*sin(t);
	xprop[0] = xx, xprop[1] = yy;
	
	rowvec logrb = zeros<rowvec>(count);
	for(int i = 0; i< count; i++){
	   	distance = sqrt( (xprop[0] - loc(i,0))*(xprop[0] - loc(i,0)) + (xprop[1] - loc(i,1))*(xprop[1] - loc(i,1)) );
	   	
        if(distance>100){
        logrb[i] = log(1);
        }else if ( (distance>r1) && (distance<=100) ){
        logrb[i] = log( 1 + 1/(t3*t3*(distance-r2)*(distance-r2)) );
        }else if ( (distance>R) && (distance<=r1) ){
        logrb[i] = log( t1 - (sqrt(t1)*(distance-t2)/(t2-R))*(sqrt(t1)*(distance-t2)/(t2-R)) );
        }	  	
	}
	
	rowvec rhosum = rho0sum + logrb;
    rhosum.insert_cols(count,1);
    rhosum[count] = sum(trans(logrb));
    
    likelihood = 0; 
	for(int i = 0; i<count+1; i++){
    	likelihood = min(rhosum[i],1.2) + likelihood;
    }
    
    logratio = ( log(0.5) + log(lambda) + likelihood + log( M_PI*pow((range),2) ) ) - 
               ( log(0.5) + likelihoodprev + log(count+1) ) ;
    
    logv = log( randu() );
    if( logv < logratio ){
	loc.insert_rows(count,xprop);
    rho0sum = zeros<rowvec>(count+1);
	rho0sum = rhosum;  			
	}
	
	}else{         

	int Death = count*randu();
	xprop[0] = loc(Death,0), xprop[1] = loc(Death,1);
	
	rowvec logrd = zeros<rowvec>(count);
	for(int i = 0; i< count; i++){
	   	distance = sqrt( (xprop[0] - loc(i,0))*(xprop[0] - loc(i,0)) + (xprop[1] - loc(i,1))*(xprop[1] - loc(i,1)) );
	   	
        if(distance>100){
        logrd[i] = log(1);
        }else if ( (distance>r1) && (distance<=100) ){
        logrd[i] = log( 1 + 1/(t3*t3*(distance-r2)*(distance-r2)) );
        }else if ( (distance>R) && (distance<=r1) ){
        logrd[i] = log( t1 - (sqrt(t1)*(distance-t2)/(t2-R))*(sqrt(t1)*(distance-t2)/(t2-R)) );
        }  	
	}
	
	rowvec rhosum = rho0sum - logrd;
	rhosum.shed_col(Death);
	
	likelihood = 0; 
	for(int i = 0; i<count-1; i++){
    	likelihood = min(rhosum[i],1.2) + likelihood;
    }
   
    logratio = ( log(0.5) + likelihood + log(count) ) - 
               ( log(0.5) + log(lambda) + likelihoodprev + log( M_PI*pow((range),2) ) );
			   	
	logv = log( randu() );
    if( logv < logratio ){
    loc.shed_row(Death);
	rho0sum = zeros<rowvec>(count-1);		
   	rho0sum = rhosum;  			
	}			
	}
	
  }
  
return(loc);        	       	
}




// [[Rcpp::export]]
mat DMH(vec center, double range, mat initial, mat initialdist, double lhX, int Niter, mat theta, mat COV, int n){


double R = 0, negativeInf = -std::numeric_limits<float>::infinity();;	
double logprob,u,lhXp, lhY, lhYp;                  
int nCOVcols = COV.n_cols;                         
vec thetaprev(nCOVcols);                           
int nrow = initialdist.n_rows;                       



for(int l = 0; l< Niter; l++){

	if( (l > 1000) && (l <= 10000) ){ 
	COV = cov(theta);
    }	

    for(int i = 0; i< nCOVcols; i++){
    	thetaprev[i] = theta(l,i);
    }
    
    vec Znormal = randn(nCOVcols);                                          
    vec thetaprop = trans(  trans(thetaprev) + trans(Znormal)*chol(COV)  );  


	if( thetaprop[0] > 6e-4 || thetaprop[0] < 2e-4 || thetaprop[1] > 2 || thetaprop[1] < 1 || thetaprop[2] > 20 || thetaprop[2] < 0  || thetaprop[3] > 1 || thetaprop[3] < 0 ){
	logprob = negativeInf;	
	}else{
		

	mat Y = BDmcmc(center, range, initial, initialdist, thetaprop,  n);
	int count = Y.n_rows;
	

	vec rp = coeff(thetaprop), r = coeff(thetaprev);
    double r1p = rp[0], r2p = rp[1], lambdap= thetaprop[0], t1p = thetaprop[1], t2p = thetaprop[2], t3p = thetaprop[3];
    double r1 = r[0], r2 = r[1], lambda= thetaprev[0], t1 = thetaprev[1], t2 = thetaprev[2], t3 = thetaprev[3];


 
    mat resultXp(nrow,nrow);    
	for(int i = 0; i < nrow; i++){
    for(int j = 0; j <= i; j++){
    	
        if(initialdist(i,j)>100){
        resultXp(i,j) = resultXp(j,i) = log(1);
        }else if ( (initialdist(i,j)>r1p) && (initialdist(i,j)<=100) ){
        resultXp(i,j) = resultXp(j,i) = log( 1 + 1/(t3p*t3p*(initialdist(i,j)-r2p)*(initialdist(i,j)-r2p)) );
        }else if ( (initialdist(i,j)>R) && (initialdist(i,j)<=r1p) ){
        resultXp(i,j) = resultXp(j,i) = log( t1p - (sqrt(t1p)*(initialdist(i,j)-t2p)/(t2p-R))*(sqrt(t1p)*(initialdist(i,j)-t2p)/(t2p-R)) );
        }else {
        resultXp(i,j) = resultXp(j,i) = 0;
        }
        }
    }  
    
    rowvec rhoXpsum = sum(resultXp);                    
    lhXp = 0;
	for(int i = 0; i<nrow; i++){
    	lhXp = min(rhoXpsum[i],1.2) + lhXp;
        }
    lhXp = lhXp + (nrow)*log(lambdap);              


    double distanceY;
    mat resultY(count,count), resultYp(count,count);
    for(int i = 0; i < count; i++){
    for(int j = 0; j <= i; j++){
    distanceY = sqrt( (Y(i,0) - Y(j,0))*(Y(i,0) - Y(j,0)) + (Y(i,1) - Y(j,1))*(Y(i,1) - Y(j,1)) );	
    
        if(distanceY>100){
        resultY(i,j) = resultY(j,i) = log(1);
        }else if ( (distanceY>r1) && (distanceY<=100) ){
        resultY(i,j) = resultY(j,i) = log( 1 + 1/(t3*t3*(distanceY-r2)*(distanceY-r2)) );
        }else if ( (distanceY>R) && (distanceY<=r1) ){
        resultY(i,j) = resultY(j,i) = log( t1 - (sqrt(t1)*(distanceY-t2)/(t2-R))*(sqrt(t1)*(distanceY-t2)/(t2-R)) );
        }else {
        resultY(i,j) = resultY(j,i) = 0;
        }
        
        if(distanceY>100){
        resultYp(i,j) = resultYp(j,i) = log(1);
        }else if ( (distanceY>r1p) && (distanceY<=100) ){
        resultYp(i,j) = resultYp(j,i) = log( 1 + 1/(t3p*t3p*(distanceY-r2p)*(distanceY-r2p)) );
        }else if ( (distanceY>R) && (distanceY<=r1p) ){
        resultYp(i,j) = resultYp(j,i) = log( t1p - (sqrt(t1p)*(distanceY-t2p)/(t2p-R))*(sqrt(t1p)*(distanceY-t2p)/(t2p-R)) );
        }else {
        resultYp(i,j) = resultYp(j,i) = 0;
        }
        
        }
    }  
    
    rowvec rhoYsum = sum(resultY), rhoYpsum = sum(resultYp);  
    lhY = 0, lhYp = 0; 
    for(int i = 0; i<count; i++){
    	lhY = min(rhoYsum[i],1.2) + lhY;
    	lhYp = min(rhoYpsum[i],1.2) + lhYp;
        }
    lhY = lhY + (count)*log(lambda);   
    lhYp = lhYp + (count)*log(lambdap);  


    logprob = ( lhXp + lhY ) - ( lhX + lhYp ) ;  
	}

    u = log( randu() );
    if( u< logprob ){
    theta.insert_rows(l+1,trans(thetaprop));
    lhX = lhXp;	
	}else{
	theta.insert_rows(l+1,trans(thetaprev));
	}
		
}

return theta;
}




// [[Rcpp::export]]
mat pResponse(vec center, double range, mat initial, mat initialdist, vec hatparameter, int inner, mat Designmat, int m, int num){

int thnrow = Designmat.n_rows;             
mat H(m,thnrow);                          
omp_set_num_threads(num);


vec rhat = coeff(hatparameter);
double r1 = rhat[0], r2 = rhat[1], lambda= hatparameter[0], t1 = hatparameter[1], t2 = hatparameter[2], t3 = hatparameter[3], R = 0;



int M;
#pragma omp parallel shared(Designmat) private(M)
{	
#pragma omp for schedule(static)  
for(M = 0; M < m; M++){                 

    mat loc = BDmcmc(center, range, initial, initialdist, hatparameter, inner);    
    int count = loc.n_rows;                                                      
    double locdistance;                                                     
    	   
    for(int k = 0; k < thnrow; k++){
        

        vec parameter = trans( Designmat.row( k ) );
        vec r = coeff(parameter);
        double R1 = r[0], R2 = r[1], Lambda= parameter[0], T1 = parameter[1], T2 = parameter[2], T3 = parameter[3];	
   
        double likelihood = 0;     
        double sumResult = 0;     
        double result = 0;         
        
        double Likelihood = 0;     
        double SumResult = 0;      
        double Result = 0;         
        	    	
        for(int i = 0; i < count; i++){
        	    sumResult = 0;
	            SumResult = 0;
	        
                for(int j = 0; j < count; j++){
	                result = 0;
			        Result = 0; 

		
                    locdistance = sqrt( (loc(i,0)-loc(j,0))*(loc(i,0)-loc(j,0)) + (loc(i,1)-loc(j,1))*(loc(i,1)-loc(j,1)) );
            
                
                    if(locdistance>100){
                        result = log(1);
                    }else if ( (locdistance>r1) && (locdistance<=100) ){
                        result = log( 1 + 1/(t3*t3*(locdistance-r2)*(locdistance-r2)) );
                    }else if ( (locdistance>R) && (locdistance<=r1) ){
                        result = log( t1 - (sqrt(t1)*(locdistance-t2)/(t2-R))*(sqrt(t1)*(locdistance-t2)/(t2-R)) );
                    }
                
                  
                    if(locdistance>100){
                        Result  = log(1);
                    }else if ( (locdistance>R1) && (locdistance<=100) ){
                        Result  = log( 1 + 1/(T3*T3*(locdistance-R2)*(locdistance-R2)) );
                    }else if ( (locdistance>R) && (locdistance<=R1) ){
                        Result  = log( T1 - (sqrt(T1)*(locdistance-T2)/(T2-R))*(sqrt(T1)*(locdistance-T2)/(T2-R)) );
                    }
                                         
                    sumResult = sumResult + result ;
                    SumResult = SumResult + Result ;
                    }   
				    likelihood  = likelihood  + min(sumResult,1.2);    
                    Likelihood = Likelihood + min(SumResult,1.2); 
    	        }


        H(M,k) = ( Likelihood + count*log(Lambda) ) - ( likelihood + count*log(lambda) );                                    
        }

   }
}
return(H);        	
}




// [[Rcpp::export]]
mat GPmcmc(int Niter, mat theta, mat COV, double lhXZ, vec betahat, vec phihat, mat Designmat, vec y, mat Distmat){
	int thnrow = Designmat.n_rows;                                                 
	int nCOVcols = COV.n_cols;                                                    
	int nrow = Distmat.n_rows;                                                   
    mat result(nrow,nrow);                                                        
    rowvec rhosum(nrow);                                                          
	vec thetaprev(nCOVcols);                                                      
	
	double lhXZp,logprob,u;                                   
	double negativeInf = -std::numeric_limits<float>::infinity();;	               
	double phi1hat = phihat[0], phi2hat = phihat[1], phi3hat = phihat[2], phi4hat = phihat[3], sigmasqhat = phihat[4]; 
	

	mat Domain(2,nCOVcols);                                                         
	for(int i = 0; i < nCOVcols; i++){
	vec dummy = sort( Designmat.col( i ) );
  
	Domain(0,i) = dummy(0);
	Domain(1,i) = dummy(thnrow-1);
         }
	
	mat h1(thnrow,thnrow), h2(thnrow,thnrow), h3(thnrow,thnrow), h4(thnrow,thnrow); 
    vec h1dcross(thnrow), h2dcross(thnrow), h3dcross(thnrow), h4dcross(thnrow);    
    
    for(int i = 0; i < thnrow; i++){
        for(int j = 0; j <= i; j++){
	        h1(i,j) = h1(j,i) = fabs(Designmat(i,0)-Designmat(j,0));
	        h2(i,j) = h2(j,i) = fabs(Designmat(i,1)-Designmat(j,1));
	        h3(i,j) = h3(j,i) = fabs(Designmat(i,2)-Designmat(j,2));
	        h4(i,j) = h4(j,i) = fabs(Designmat(i,3)-Designmat(j,3));
	    }
	}
	mat Sigma = sigmasqhat*(1+sqrt(3)*h1/phi1hat)%exp(-sqrt(3)*h1/phi1hat)%(1+sqrt(3)*h2/phi2hat)%exp(-sqrt(3)*h2/phi2hat)%
	                       (1+sqrt(3)*h3/phi3hat)%exp(-sqrt(3)*h3/phi3hat)%(1+sqrt(3)*h4/phi4hat)%exp(-sqrt(3)*h4/phi4hat);
	mat InvSigma = inv(Sigma);	    
	mat Xth = ones(thnrow,1);
    Xth.insert_cols(1,Designmat);	
	


	for(int k = 0; k< Niter; k++){
	    if( (k > 1000) && (k <= 10000) ){ 
	    COV = cov(theta);
        }	
        vec Znormal = randn(nCOVcols); 
    	for(int i = 0; i< nCOVcols; i++){
    		thetaprev[i] = theta(k,i);
		}
		
	
    	vec thetaprop = trans(  trans(thetaprev) + trans(Znormal)*chol(COV)  );
     	vec r = coeff(thetaprop);
        double r1 = r[0], r2 = r[1],  lambda = thetaprop[0], t1 = thetaprop[1], t2 = thetaprop[2], t3 = thetaprop[3], R=0; 

        if( lambda > Domain(1,0) || lambda < Domain(0,0) || t1 > Domain(1,1) || t1 < Domain(0,1) || t2 > Domain(1,2) || t2 < Domain(0,2) || t3 > Domain(1,3) || t3 < Domain(0,3) ){
		logprob = negativeInf;	
		}else{			
		for(int i = 0; i< thnrow; i++){  
    		h1dcross[i] =  fabs(lambda-Designmat(i,0));
			h2dcross[i] =  fabs(t1-Designmat(i,1));
			h3dcross[i] =  fabs(t2-Designmat(i,2));
			h4dcross[i] =  fabs(t3-Designmat(i,3));		
		}
    	mat Sigmacross = sigmasqhat*(1+sqrt(3)*h1dcross/phi1hat)%exp(-sqrt(3)*h1dcross/phi1hat)%(1+sqrt(3)*h2dcross/phi2hat)%exp(-sqrt(3)*h2dcross/phi2hat)%
	    	                        (1+sqrt(3)*h3dcross/phi3hat)%exp(-sqrt(3)*h3dcross/phi3hat)%(1+sqrt(3)*h4dcross/phi4hat)%exp(-sqrt(3)*h4dcross/phi4hat);
    	vec xpoint = ones(1);
    	xpoint.insert_rows(1,thetaprop);
    	lhXZp = (trans(xpoint)*betahat + trans(Sigmacross)* InvSigma*(y-Xth*betahat))[0]; 
   
    	logprob = lhXZp - lhXZ; 
        } 

        u = log( randu() );
    	if( u< logprob ){
    	theta.insert_rows(k+1,trans(thetaprop));
          lhXZ = lhXZp;		
		}else{
	    theta.insert_rows(k+1,trans(thetaprev));
		}

   }
		
return theta;
}







// [[Rcpp::export]]
vec pcfval(vec center, double range, mat Y, vec pcfdist){

    int count = Y.n_rows;                 
    int numval = pcfdist.n_elem;         
    double delta = 5;                      
    double areaW = (M_PI)*pow(range,2);    


    double val;       
	double offdist;         

	vec result = zeros(numval); 
    vec c = 2*3/(4*delta)/count*(areaW/(2*(M_PI)*pcfdist*count));  
    pcfdist = pcfdist/delta; 
    
    	
        for(int i = 1; i < count; i++){
            for(int j = 0; j < i; j++){
            	offdist = sqrt( (Y(i,0) - Y(j,0))*(Y(i,0) - Y(j,0)) + (Y(i,1) - Y(j,1))*(Y(i,1) - Y(j,1)) )/delta;  
            	
            	for(int k = 0; k < numval; k++){
 	            val= 1-pow(   ( offdist - pcfdist[k] ) ,   2);   
		        result[k] = result[k] + c[k]*val*(val>0);  
                }
    	
		    }    	
        }  
    

    pcfdist = pcfdist*delta;
    uvec ind = sort_index( result );       
    int maxind = ind[numval-1];
    int maxind2 = min(  2*(maxind+1), numval-1    );
    vec Summary(4);
    Summary[0] = count/areaW, Summary[1] = result[maxind], Summary[2] = pcfdist[maxind];
	Summary[3] = 10*(result[maxind2]-Summary[1])/(pcfdist[maxind2]-pcfdist[maxind]) ;
    
 
    Summary[0] = ( Summary[0] - 2e-4 )/4e-4, Summary[1] = Summary[1]-1, Summary[2] = (Summary[2]-5)/15;
    
return(result);	
}  




