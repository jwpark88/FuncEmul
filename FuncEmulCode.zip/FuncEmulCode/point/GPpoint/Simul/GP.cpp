#include <RcppArmadillo.h>
#include <limits>
#include <omp.h>
#define min(x,y) (((x) < (y)) ? (x) : (y))

using namespace std;
using namespace Rcpp;
using namespace arma;


// [[Rcpp::depends("RcppArmadillo")]]
// [[Rcpp::export]]
// calculate r1 and r2
vec coeff(vec parameter){
	
vec r(2);
double lambda = parameter[0], t1 = parameter[1], t2 = parameter[2], t3 = parameter[3], R = 0; 
double a = (t2-R)*(t2-R)/(t1*t3*t3); 
double b = t3*t3*(t1 - 1);
double d = 27*a*b*b;
double c = pow(d + sqrt((d+2)*(d+2)-4) + 2,1.0/3.0); 
double deltar = 1/(3*b) * ( c/pow(2,1.0/3.0) + pow(2,1.0/3.0)/c + 1 );
r[0] = a / pow(deltar,1.5)+ t2;
r[1] = r[0] - sqrt(deltar);

return(r);	
}



// [[Rcpp::depends("RcppArmadillo")]]
// [[Rcpp::export]]
// Birth Death MCMC 
mat BDmcmc(vec center, double range, mat initial, mat initialdist, vec parameter, int n){
	
// Initializing part 
vec r = coeff(parameter);
double r1 = r[0], r2 = r[1], lambda= parameter[0], t1 = parameter[1], t2 = parameter[2], t3 = parameter[3], R = 0;
              
int nrow = initialdist.n_rows;       // initial Data's distance matrix row numbers
mat result(nrow,nrow);               // rho matrix result
rowvec rho0sum(nrow);                // row sum of rho matrix
rowvec xprop(2);                     // proposed points in Birth Death MCMC
double logratio,logv;                // log acceptance ratio used in Birth Death MCMC

for(int i = 0; i < nrow; i++){
    for(int j = 0; j <= i; j++){
    	
        if(initialdist(i,j)>100){
        result(i,j) = result(j,i) = log(1);
        }else if ( (initialdist(i,j)>r1) && (initialdist(i,j)<=100) ){
        result(i,j) = result(j,i) = log( 1 + 1/(t3*t3*(initialdist(i,j)-r2)*(initialdist(i,j)-r2)) );
        }else if ( (initialdist(i,j)>R) && (initialdist(i,j)<=r1) ){
        result(i,j) = result(j,i) = log( t1 - (sqrt(t1)*(initialdist(i,j)-t2)/(t2-R))*(sqrt(t1)*(initialdist(i,j)-t2)/(t2-R)) );
        }
        
        }
    } 
        	
rho0sum = sum(result);                       // previous rho sum 
double distance;                                
double likelihood,likelihoodprev;            // likelihood (exponential part)
mat loc = initial;                           // will be updated point location

// Birth Death MCMC part 			
double p1 = 0.5, p2 = 0.5;    // Birth and Death probability 
for(int k = 0; k < n; k++){

    int count = loc.n_rows;
    likelihoodprev = 0; 
    for(int i = 0; i<count; i++){
  	    likelihoodprev = min(rho0sum[i],1.2) + likelihoodprev;   
   	    }  	
   	    
	double u = randu();
	if( u < p1 ){  // Birt step 
	// uniformly proposed points around circle
	double radius = sqrt(   pow((range),2)*randu()   );
	double t = 2*(M_PI)*randu();
	double xx = center[0]+radius*cos(t), yy = center[1]+radius*sin(t);
	xprop[0] = xx, xprop[1] = yy;
	
	rowvec logrb = zeros<rowvec>(count);
	for(int i = 0; i< count; i++){
	   	distance = sqrt( (xprop[0] - loc(i,0))*(xprop[0] - loc(i,0)) + (xprop[1] - loc(i,1))*(xprop[1] - loc(i,1)) );
	   	
        if(distance>100){
        logrb[i] = log(1);
        }else if ( (distance>r1) && (distance<=100) ){
        logrb[i] = log( 1 + 1/(t3*t3*(distance-r2)*(distance-r2)) );
        }else if ( (distance>R) && (distance<=r1) ){
        logrb[i] = log( t1 - (sqrt(t1)*(distance-t2)/(t2-R))*(sqrt(t1)*(distance-t2)/(t2-R)) );
        }	  	
	}
	
	rowvec rhosum = rho0sum + logrb;
    rhosum.insert_cols(count,1);
    rhosum[count] = sum(trans(logrb));
    
    likelihood = 0; 
	for(int i = 0; i<count+1; i++){
    	likelihood = min(rhosum[i],1.2) + likelihood;
    }
    
    logratio = ( log(0.5) + log(lambda) + likelihood + log( M_PI*pow((range),2) ) ) - 
               ( log(0.5) + likelihoodprev + log(count+1) ) ;
    
    logv = log( randu() );
    if( logv < logratio ){
	loc.insert_rows(count,xprop);
    rho0sum = zeros<rowvec>(count+1);
	rho0sum = rhosum;  			
	}
	
	}else{         // Death step
	// uniformly proposed death
	int Death = count*randu();
	xprop[0] = loc(Death,0), xprop[1] = loc(Death,1);
	
	rowvec logrd = zeros<rowvec>(count);
	for(int i = 0; i< count; i++){
	   	distance = sqrt( (xprop[0] - loc(i,0))*(xprop[0] - loc(i,0)) + (xprop[1] - loc(i,1))*(xprop[1] - loc(i,1)) );
	   	
        if(distance>100){
        logrd[i] = log(1);
        }else if ( (distance>r1) && (distance<=100) ){
        logrd[i] = log( 1 + 1/(t3*t3*(distance-r2)*(distance-r2)) );
        }else if ( (distance>R) && (distance<=r1) ){
        logrd[i] = log( t1 - (sqrt(t1)*(distance-t2)/(t2-R))*(sqrt(t1)*(distance-t2)/(t2-R)) );
        }  	
	}
	
	rowvec rhosum = rho0sum - logrd;
	rhosum.shed_col(Death);
	
	likelihood = 0; 
	for(int i = 0; i<count-1; i++){
    	likelihood = min(rhosum[i],1.2) + likelihood;
    }
   
    logratio = ( log(0.5) + likelihood + log(count) ) - 
               ( log(0.5) + log(lambda) + likelihoodprev + log( M_PI*pow((range),2) ) );
			   	
	logv = log( randu() );
    if( logv < logratio ){
    loc.shed_row(Death);
	rho0sum = zeros<rowvec>(count-1);		
   	rho0sum = rhosum;  			
	}			
	}
	
  }
  
return(loc);        	       	
}



// [[Rcpp::depends("RcppArmadillo")]]
// [[Rcpp::export]]
// Double Metropolis Hastings for attraction repulsion example

mat DMH(vec center, double range, mat initial, mat initialdist, double lhX, int Niter, mat theta, mat COV, int n){

// Initializing part
double R = 0, negativeInf = -std::numeric_limits<float>::infinity();;	
double logprob,u,lhXp, lhY, lhYp;                   // used in Outer MCMC
int nCOVcols = COV.n_cols;                          // number of parameters	
vec thetaprev(nCOVcols);                            // before propose in Outer MCMC, previous parameters
int nrow = initialdist.n_rows;                      // initial Data's number of points           


//// Start of OUTER MCMC Chain 
for(int l = 0; l< Niter; l++){

	if( (l > 1000) && (l <= 10000) ){ // adaptively update COV until 10000 iterations 
	COV = cov(theta);
    }	

    for(int i = 0; i< nCOVcols; i++){
    	thetaprev[i] = theta(l,i);
    }
    
    vec Znormal = randn(nCOVcols);                                           // multivariate proposal by using Cholesky factorization
    vec thetaprop = trans(  trans(thetaprev) + trans(Znormal)*chol(COV)  );  // proposed parameter

	// constraints on prior space
	if( thetaprop[0] > 6e-4 || thetaprop[0] < 2e-4 || thetaprop[1] > 2 || thetaprop[1] < 1 || thetaprop[2] > 20 || thetaprop[2] < 0  || thetaprop[3] > 1 || thetaprop[3] < 0 ){
	logprob = negativeInf;	
	}else{
		
    // proposed auxiliary variable		
	mat Y = BDmcmc(center, range, initial, initialdist, thetaprop,  n);
	int count = Y.n_rows;
	
	// calculate coefficients for rho function	
	vec rp = coeff(thetaprop), r = coeff(thetaprev);
    double r1p = rp[0], r2p = rp[1], lambdap= thetaprop[0], t1p = thetaprop[1], t2p = thetaprop[2], t3p = thetaprop[3];
    double r1 = r[0], r2 = r[1], lambda= thetaprev[0], t1 = thetaprev[1], t2 = thetaprev[2], t3 = thetaprev[3];


    // lhX is already given     
    // lhXp      
    mat resultXp(nrow,nrow);    
	for(int i = 0; i < nrow; i++){
    for(int j = 0; j <= i; j++){
    	
        if(initialdist(i,j)>100){
        resultXp(i,j) = resultXp(j,i) = log(1);
        }else if ( (initialdist(i,j)>r1p) && (initialdist(i,j)<=100) ){
        resultXp(i,j) = resultXp(j,i) = log( 1 + 1/(t3p*t3p*(initialdist(i,j)-r2p)*(initialdist(i,j)-r2p)) );
        }else if ( (initialdist(i,j)>R) && (initialdist(i,j)<=r1p) ){
        resultXp(i,j) = resultXp(j,i) = log( t1p - (sqrt(t1p)*(initialdist(i,j)-t2p)/(t2p-R))*(sqrt(t1p)*(initialdist(i,j)-t2p)/(t2p-R)) );
        }else {
        resultXp(i,j) = resultXp(j,i) = 0;
        }
        }
    }  
    
    rowvec rhoXpsum = sum(resultXp);                    
    lhXp = 0;
	for(int i = 0; i<nrow; i++){
    	lhXp = min(rhoXpsum[i],1.2) + lhXp;
        }
    lhXp = lhXp + (nrow)*log(lambdap);              // calculatable likelihood part for initial data given proposed parameter    
    

    // lhY and lhYp
    double distanceY;
    mat resultY(count,count), resultYp(count,count);
    for(int i = 0; i < count; i++){
    for(int j = 0; j <= i; j++){
    distanceY = sqrt( (Y(i,0) - Y(j,0))*(Y(i,0) - Y(j,0)) + (Y(i,1) - Y(j,1))*(Y(i,1) - Y(j,1)) );	
    
        if(distanceY>100){
        resultY(i,j) = resultY(j,i) = log(1);
        }else if ( (distanceY>r1) && (distanceY<=100) ){
        resultY(i,j) = resultY(j,i) = log( 1 + 1/(t3*t3*(distanceY-r2)*(distanceY-r2)) );
        }else if ( (distanceY>R) && (distanceY<=r1) ){
        resultY(i,j) = resultY(j,i) = log( t1 - (sqrt(t1)*(distanceY-t2)/(t2-R))*(sqrt(t1)*(distanceY-t2)/(t2-R)) );
        }else {
        resultY(i,j) = resultY(j,i) = 0;
        }
        
        if(distanceY>100){
        resultYp(i,j) = resultYp(j,i) = log(1);
        }else if ( (distanceY>r1p) && (distanceY<=100) ){
        resultYp(i,j) = resultYp(j,i) = log( 1 + 1/(t3p*t3p*(distanceY-r2p)*(distanceY-r2p)) );
        }else if ( (distanceY>R) && (distanceY<=r1p) ){
        resultYp(i,j) = resultYp(j,i) = log( t1p - (sqrt(t1p)*(distanceY-t2p)/(t2p-R))*(sqrt(t1p)*(distanceY-t2p)/(t2p-R)) );
        }else {
        resultYp(i,j) = resultYp(j,i) = 0;
        }
        
        }
    }  
    
    rowvec rhoYsum = sum(resultY), rhoYpsum = sum(resultYp);  
    lhY = 0, lhYp = 0; 
    for(int i = 0; i<count; i++){
    	lhY = min(rhoYsum[i],1.2) + lhY;
    	lhYp = min(rhoYpsum[i],1.2) + lhYp;
        }
    lhY = lhY + (count)*log(lambda);   
    lhYp = lhYp + (count)*log(lambdap);  


    logprob = ( lhXp + lhY ) - ( lhX + lhYp ) ;  // log probability ratio to determine acceptance of Outer MCMC 	    
	}

    u = log( randu() );
    if( u< logprob ){
    theta.insert_rows(l+1,trans(thetaprop));
    lhX = lhXp;	
	}else{
	theta.insert_rows(l+1,trans(thetaprev));
	}
		
}
//// End of Outer MCMC ////
return theta;
}



// [[Rcpp::depends("RcppArmadillo")]]
// [[Rcpp::export]]
mat pResponse(vec center, double range, mat initial, mat initialdist, vec hatparameter, int inner, mat Designmat, int m, int num){

int thnrow = Designmat.n_rows;             // number of design points   
mat H(m,thnrow);                           // matrix where ratio of likelihood for importance sampling estimate will be stored. (m by thnrow)
omp_set_num_threads(num);

// coefficients of rho function for hatparameter (sampled points)
vec rhat = coeff(hatparameter);
double r1 = rhat[0], r2 = rhat[1], lambda= hatparameter[0], t1 = hatparameter[1], t2 = hatparameter[2], t3 = hatparameter[3], R = 0;


//////    START OF BIGGEST CHAIN (M)     ////// 
int M;
#pragma omp parallel shared(Designmat) private(M)
{	
#pragma omp for schedule(static)  
for(M = 0; M < m; M++){                  // m is number of importance sampling estimate 

    mat loc = BDmcmc(center, range, initial, initialdist, hatparameter, inner);     // Sampled data
    int count = loc.n_rows;                                                      // number of poinst for Sampled data
    double locdistance;                                                          // distance for sampled data
    	   
    for(int k = 0; k < thnrow; k++){
        
		// redefine all coefficients of rho function for design points. 
        vec parameter = trans( Designmat.row( k ) );
        vec r = coeff(parameter);
        double R1 = r[0], R2 = r[1], Lambda= parameter[0], T1 = parameter[1], T2 = parameter[2], T3 = parameter[3];	
   
        double likelihood = 0;     // calculated Likelihood for sampled data from Birth Death MCMC at parameter (sampled points).   
        double sumResult = 0;      // row sum of rho matrix for sampled data from Birth Death MCMC at parameter (sampled points).
        double result = 0;         // rho matrix for sampled data from Birth Death MCMC at parameter (sampled points).
        
        double Likelihood = 0;     // calculated Likelihood for sampled data from Birth Death MCMC at design points.
        double SumResult = 0;      // row sum of rho matrix for sampled data from Birth Death MCMC at design points.
        double Result = 0;         // rho matrix for sampled data from Birth Death MCMC at design points.
        	    	
        for(int i = 0; i < count; i++){
        	    sumResult = 0;
	            SumResult = 0;
	        
                for(int j = 0; j < count; j++){
	                result = 0;
			        Result = 0; 

			        // calculate distance for sampled data
                    locdistance = sqrt( (loc(i,0)-loc(j,0))*(loc(i,0)-loc(j,0)) + (loc(i,1)-loc(j,1))*(loc(i,1)-loc(j,1)) );
            
                    // checked for sampled points         
                    if(locdistance>100){
                        result = log(1);
                    }else if ( (locdistance>r1) && (locdistance<=100) ){
                        result = log( 1 + 1/(t3*t3*(locdistance-r2)*(locdistance-r2)) );
                    }else if ( (locdistance>R) && (locdistance<=r1) ){
                        result = log( t1 - (sqrt(t1)*(locdistance-t2)/(t2-R))*(sqrt(t1)*(locdistance-t2)/(t2-R)) );
                    }
                
                    // checked for each design points
                    if(locdistance>100){
                        Result  = log(1);
                    }else if ( (locdistance>R1) && (locdistance<=100) ){
                        Result  = log( 1 + 1/(T3*T3*(locdistance-R2)*(locdistance-R2)) );
                    }else if ( (locdistance>R) && (locdistance<=R1) ){
                        Result  = log( T1 - (sqrt(T1)*(locdistance-T2)/(T2-R))*(sqrt(T1)*(locdistance-T2)/(T2-R)) );
                    }
                                         
                    sumResult = sumResult + result ;
                    SumResult = SumResult + Result ;
                    }   
				    likelihood  = likelihood  + min(sumResult,1.2);    
                    Likelihood = Likelihood + min(SumResult,1.2); 
    	        }


        H(M,k) = ( Likelihood + count*log(Lambda) ) - ( likelihood + count*log(lambda) );                                    
        }

   }
}
return(H);        	
}


#include <RcppArmadillo.h>
#include <limits>
#include <omp.h>
#define min(x,y) (((x) < (y)) ? (x) : (y))

using namespace Rcpp;
using namespace arma;
// [[Rcpp::depends("RcppArmadillo")]]
// [[Rcpp::export]]


mat GPmcmc(int Niter, mat theta, mat COV, double lhX, double logconst, vec betahat, vec phihat, mat Designmat, vec y, mat Distmat){
	int thnrow = Designmat.n_rows;                                                 // number of design points
	int nCOVcols = COV.n_cols;                                                     // number of parameters
	int nrow = Distmat.n_rows;                                                     // Data's distance matrix row numbers
    mat result(nrow,nrow);                                                         // rho matrix result
    rowvec rhosum(nrow);                                                           // row sum of rho matrix
	vec thetaprev(nCOVcols);                                                       // befor propose in MCMC, previous parameters
	
	double lhXp,logconstp,logprob,u,likelihood;                                    // used in MCMC step
	double negativeInf = -std::numeric_limits<float>::infinity();;	               
	double phi1hat = phihat[0], phi2hat = phihat[1], phi3hat = phihat[2], phi4hat = phihat[3], sigmasqhat = phihat[4]; 
	
	// percentile is same as 1 when 400 design points
	int percentile = 0.0025*thnrow; 
	
	// boundary from design points
	mat Domain(2,nCOVcols);                                                         
	for(int i = 0; i < nCOVcols; i++){
	vec dummy = sort( Designmat.col( i ) );
	Domain(0,i) = dummy(percentile);
	Domain(1,i) = dummy(thnrow-1-percentile);
    }
	
	mat h1(thnrow,thnrow), h2(thnrow,thnrow), h3(thnrow,thnrow), h4(thnrow,thnrow); // used to construct Sigma in Gaussian process
    vec h1dcross(thnrow), h2dcross(thnrow), h3dcross(thnrow), h4dcross(thnrow);     // used to construct cross Sigma in Gaussian process
    
    for(int i = 0; i < thnrow; i++){
        for(int j = 0; j <= i; j++){
	        h1(i,j) = h1(j,i) = fabs(Designmat(i,0)-Designmat(j,0));
	        h2(i,j) = h2(j,i) = fabs(Designmat(i,1)-Designmat(j,1));
	        h3(i,j) = h3(j,i) = fabs(Designmat(i,2)-Designmat(j,2));
	        h4(i,j) = h4(j,i) = fabs(Designmat(i,3)-Designmat(j,3));
	    }
	}
	mat Sigma = sigmasqhat*(1+sqrt(3)*h1/phi1hat)%exp(-sqrt(3)*h1/phi1hat)%(1+sqrt(3)*h2/phi2hat)%exp(-sqrt(3)*h2/phi2hat)%
	                       (1+sqrt(3)*h3/phi3hat)%exp(-sqrt(3)*h3/phi3hat)%(1+sqrt(3)*h4/phi4hat)%exp(-sqrt(3)*h4/phi4hat);
	mat InvSigma = inv(Sigma);	    // Inverse of Sigma in Gaussian process
	mat Xth = ones(thnrow,1);
    Xth.insert_cols(1,Designmat);	// make design matrix for linear model 
	

	 // Start of MCMC Chain 
	for(int k = 0; k< Niter; k++){
	    if( (k > 1000) && (k <= 10000) ){ // adaptively update COV until 10000 iterations 
	    COV = cov(theta);
        }	
        vec Znormal = randn(nCOVcols); // multivariate proposal by using Cholesky factorization
    	for(int i = 0; i< nCOVcols; i++){
    		thetaprev[i] = theta(k,i);
		}
		
		// proposed parameter and corresponding rho coefficients
    	vec thetaprop = trans(  trans(thetaprev) + trans(Znormal)*chol(COV)  );
     	vec r = coeff(thetaprop);
        double r1 = r[0], r2 = r[1],  lambda = thetaprop[0], t1 = thetaprop[1], t2 = thetaprop[2], t3 = thetaprop[3], R=0; 
    
	    // constranits on prior space
        if( lambda > Domain(1,0) || lambda < Domain(0,0) || t1 > Domain(1,1) || t1 < Domain(0,1) || t2 > Domain(1,2) || t2 < Domain(0,2) || t3 > Domain(1,3) || t3 < Domain(0,3) ){
		logprob = negativeInf;	
		}else{			
		for(int i = 0; i< thnrow; i++){  // Caculating cross covaraince matrix
    		h1dcross[i] =  fabs(lambda-Designmat(i,0));
			h2dcross[i] =  fabs(t1-Designmat(i,1));
			h3dcross[i] =  fabs(t2-Designmat(i,2));
			h4dcross[i] =  fabs(t3-Designmat(i,3));		
		}
    	mat Sigmacross = sigmasqhat*(1+sqrt(3)*h1dcross/phi1hat)%exp(-sqrt(3)*h1dcross/phi1hat)%(1+sqrt(3)*h2dcross/phi2hat)%exp(-sqrt(3)*h2dcross/phi2hat)%
	    	                        (1+sqrt(3)*h3dcross/phi3hat)%exp(-sqrt(3)*h3dcross/phi3hat)%(1+sqrt(3)*h4dcross/phi4hat)%exp(-sqrt(3)*h4dcross/phi4hat);
    	vec xpoint = ones(1);
    	xpoint.insert_rows(1,thetaprop);
    	logconstp = (trans(xpoint)*betahat + trans(Sigmacross)* InvSigma*(y-Xth*betahat))[0]; //Gaussian kriging for intractable term
   
    	for(int i = 0; i < nrow; i++){
        	for(int j = 0; j <= i; j++){

            	if(Distmat(i,j)>100){
               	result(i,j) = result(j,i) = log(1);
            	}else if ( (Distmat(i,j)>r1) && (Distmat(i,j)<=100) ){
               	result(i,j) = result(j,i) = log( 1 + 1/(t3*t3*(Distmat(i,j)-r2)*(Distmat(i,j)-r2)) );
            	}else if ( (Distmat(i,j)>R) && (Distmat(i,j)<=r1) ){
               	result(i,j) = result(j,i) = log( t1 - (sqrt(t1)*(Distmat(i,j)-t2)/(t2-R))*(sqrt(t1)*(Distmat(i,j)-t2)/(t2-R)) );
            	}else {
            	   result(i,j) = result(j,i) = 0;
            	}
        
            	}
        	} 

    	rhosum = sum(result);   
    	likelihood = 0;
    	for(int i = 0; i<nrow; i++){
    		likelihood = min(rhosum[i],1.2) + likelihood;
        	}
               
    	lhXp = likelihood + nrow*log(lambda); // Calculating proposed probability withouth intractable term 
    	logprob = lhXp - lhX + logconst - logconstp;  // log probability ratio to determine acceptance of MCMC 
        } 

        u = log( randu() );
    	if( u< logprob ){
    	theta.insert_rows(k+1,trans(thetaprop));
    	logconst = logconstp;
		lhX = lhXp;		
		}else{
	    theta.insert_rows(k+1,trans(thetaprev));
		}

   }
		
return theta;
}








