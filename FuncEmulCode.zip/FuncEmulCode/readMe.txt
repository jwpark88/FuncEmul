To implement the code users need to install "RcppArmadillo" and "Rcpp" packages. locate Cpp files and data files at the current directory and run the R code.

1. Each folder represents each example in the manuscript. 

2. Each example include both simulated and real data example. (except for rotavirus example). 

3. "Entire" represents full likelihood emulation approach. The other denotes normalizing function emulation approach. 


