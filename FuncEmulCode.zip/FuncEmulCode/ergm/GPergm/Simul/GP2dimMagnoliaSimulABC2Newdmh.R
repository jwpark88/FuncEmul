########## ERGM exmpales  ##########
## change statistics of gwdegree: https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2031865/#FD24 ##
## ergm basics: https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2743438/

rm(list=ls())
library(coda)
library(Bergm)
library(Rcpp)
library(RcppArmadillo)
library(DiceKriging)
library(DiceDesign)
Sys.setenv("PKG_CXXFLAGS"="-fopenmp")
Sys.setenv("PKG_LIBS"="-fopenmp")


########## Call functions ##########
source("http://www.stat.psu.edu/~mharan/batchmeans.R")
sourceCpp("GP2dimMagnolia.cpp")

########## Run step ##########

# network simulation
set.seed(1)
n <- 2000
initial <- matrix(0,n,n)

true <- c(-7,2)
ptm <- proc.time()
X <- Gibbs2(initial,true,100)
proc.time()-ptm 
Summary(X)
sum(X)

###  simulated network (1400 by 1400)  ###

X.simul <- as.network(X,directed=FALSE)

# Parameter estimation via MLE or MPLE #
formula <- X.simul ~ edges + gwesp(0.25,fixed=TRUE)
stat = summary(formula)
stat
Summary(X)

m <-ergm(formula,estimate="MPLE")
hat <- m$coef
summary(m)
COV <- solve(-m$hessian)
s1 <- sqrt( solve(-m$hessian)[1,1] )
s2 <- sqrt( solve(-m$hessian)[2,2] )


outer  <- 500
cycle <- 1
theta <- matrix(m$coef,1)
COV <- solve(-m$hessian)

ptm <- proc.time()
dmh <- ergmDMH(X, COV, theta, outer, cycle)
dmhtime = proc.time() -ptm
dmhtime


save.image("GP2dimMagnoliaSimulABC2Newdmh.RData")




