#include <RcppArmadillo.h>
#include <limits>
#include <omp.h>
#define min(x,y) (((x) < (y)) ? (x) : (y))

using namespace Rcpp;
using namespace arma;


// [[Rcpp::depends("RcppArmadillo")]]
// [[Rcpp::export]]
// Choose function
double Choose(int x, int y){
	double result1 = 1, result2 = 1, result;
	int iter = y;
	
    if( x< y ){ result = 0;	}else{	
    for(int i = 0; i<iter; i++){
    	result1 = result1*x;
    	result2 = result2*y;
    	y = y-1;
    	x = x-1;   	
	}	
    	
    	
    result = result1/result2;
	}
return(result);
}


// [[Rcpp::depends("RcppArmadillo")]]
// [[Rcpp::export]]
// Count edgewise shared partners 
vec countShared(vec rowsum, mat X){
	
	int numedges = sum(rowsum)/2, nrow = rowsum.n_elem ,ind;
	vec hist = zeros(numedges);
	int num = 0;
	for(int k = 0; k< nrow; k++){
        for(int j = 0; j< k+1; j++){
	        if( X(k,j) == 1){  for(int i = 0; i<nrow; i++){ hist(num) =  hist(num) + X(i,k)*X(k,j)*X(j,i); }
            num = num + 1; }
				            
		}
    }
	vec shared = zeros(nrow);
	for(int i = 0; i < numedges; i++ ){
	ind = hist(i);	
	if(ind>0){ shared(ind-1) = shared(ind-1) + 1; }
    }
	return(shared);
}


// [[Rcpp::depends("RcppArmadillo")]]
// [[Rcpp::export]]
// Summary statistics edges gwd gwesp
vec Summary(mat X){
	int nrow = X.n_rows;
    double decay = 0.25;
	vec rowsum = sum(X,1), result = zeros(2);
    
    // count edgewise shared partners 
    vec shared = countShared(rowsum,X);
    
    // Calculate summary statistics
    for(int i = 0; i< nrow; i++){
	result(0) = result(0) + Choose(rowsum(i),1);
	result(1) = result(1) + (   1- pow( (1-exp(-decay)),i+1)  )*shared(i);   
    }
    
    result(0)=result(0)/2;
   	result(1)=exp(decay)*result(1);   
    	 
return result;
}




// [[Rcpp::depends("RcppArmadillo")]]
// [[Rcpp::export]]
// random scan gibbs update
vec Gibbs(mat X, vec coef, int cycle){
int nrow = X.n_rows,indi,indj,prei,prej,res;
double decay = 0.25;
vec star = sum(X,1), changestat = zeros(2), Sumstat = Summary(X) ;
rowvec ivec = trans( zeros(nrow) ), jvec = trans( zeros(nrow) );
vec geoweight = zeros(nrow);
for(int i =0; i<nrow; i++){ geoweight(i) = 1- pow( (1-exp(-decay)),i+1); }


    for(int l = 0; l< cycle; l++){
    for(int i = 1; i< nrow; i++){
    for(int j = 0; j< i; j++){
         ivec(i) = 1; jvec(j) = 1;
		 res = 0; 
         	
         // When Xij is 0
         if(X(i,j)==0){  
           indi = star(i) + 1, indj = star(j) + 1; 
           // change statistics of edge
		   changestat(0) = ( Choose(indi,1) + Choose(indj,1) - Choose(star(i),1) - Choose(star(j),1) )/2;
		               
		   // change statistics of gwes
		   changestat(1) = 0;     
           for(int k = 0; k< nrow; k++){
           if(   ( X(i,k) == 1 ) & ( X(j,k) == 1  )   ){
		   prei = sum( X.row(i)%X.row(k) );
   		   prej = sum( X.row(j)%X.row(k) );

   		   changestat(1) = changestat(1) + exp(decay)*geoweight(prei+1-1) ; 
		   if(prei >0){ changestat(1) = changestat(1) - exp(decay)*geoweight(prei-1);} 
 		   changestat(1) = changestat(1) + exp(decay)*geoweight(prej+1-1) ; 
		   if(prej >0){ changestat(1) = changestat(1) - exp(decay)*geoweight(prej-1);} 
           res = res + 1; // X(k,i) multiply X(i,j) +1 multiply X(j,k)
           }
           }
           if(res > 0){ changestat(1) = changestat(1) + exp(decay)*geoweight(res-1); }
     
		   // accept reject step  	       
		   // probability of Xij = 1 for given others are fixed 
           vec r =  exp(trans(coef)*changestat) ;         
           double p = r(0)/(1+r(0));   		   
		   if( randu() < p  ){
		   X(i,j) = X(j,i) = 1; 
		   star(i) = indi; star(j) = indj;		 
		   Sumstat = Sumstat + changestat;
		   }
		   
		   
		 // When Xij is 1  
         }else{
           indi = star(i) - 1, indj = star(j) - 1;	
		   // change statistics of edge
           changestat(0) = ( Choose(star(i),1) + Choose(star(j),1) - Choose(indi,1) - Choose(indj,1) )/2;
		   		   		        
           // change statistics of gwesp 
           changestat(1) = 0;
           for(int k = 0; k< nrow; k++){
           if(   ( X(i,k) == 1 ) & ( X(j,k) == 1  )   ){
		   prei = sum( X.row(i)%X.row(k) );
   		   prej = sum( X.row(j)%X.row(k) );
   		   if(prei-1 >0){changestat(1) = changestat(1) - exp(decay)*geoweight(prei-1-1); } 
			changestat(1) = changestat(1) + exp(decay)*geoweight(prei-1); 
 		   if(prej-1 >0){changestat(1) = changestat(1) - exp(decay)*geoweight(prej-1-1); } 
			changestat(1) = changestat(1) + exp(decay)*geoweight(prej-1); 
           res = res + 1; // X(k,i) multiply X(i,j)  multiply X(j,k)
           }
           }
           if(res > 0){ changestat(1) = changestat(1) + exp(decay)*geoweight(res-1); }
		   
		   // accept reject step  	       
		   // probability of Xij = 1 for given others are fixed 
           vec r =  exp(trans(coef)*changestat) ;         
           double p = r(0)/(1+r(0));   		   
		   if( randu() > p  ){
		   X(i,j) = X(j,i) = 0; 
		   star(i) = indi; star(j) = indj;  
		   Sumstat = Sumstat - changestat;
		   }             
         }
        // End of a single update  
        ivec(i) = 0; jvec(j) = 0;
    }
    }   
    }
 
return(Sumstat); 
}


// [[Rcpp::depends("RcppArmadillo")]]
// [[Rcpp::export]]
// random scan gibbs update
// OUTPUT is matrix
mat Gibbs2(mat X, vec coef, int cycle){
int nrow = X.n_rows,indi,indj,prei,prej,res;
double decay = 0.25;
vec star = sum(X,1), changestat = zeros(2), Sumstat = Summary(X) ;
rowvec ivec = trans( zeros(nrow) ), jvec = trans( zeros(nrow) );
vec geoweight = zeros(nrow);
for(int i =0; i<nrow; i++){ geoweight(i) = 1- pow( (1-exp(-decay)),i+1); }


    for(int l = 0; l< cycle; l++){
    for(int i = 1; i< nrow; i++){
    for(int j = 0; j< i; j++){
         ivec(i) = 1; jvec(j) = 1;
		 res = 0; 
         	
         // When Xij is 0
         if(X(i,j)==0){  
           indi = star(i) + 1, indj = star(j) + 1; 
           // change statistics of edge
		   changestat(0) = ( Choose(indi,1) + Choose(indj,1) - Choose(star(i),1) - Choose(star(j),1) )/2;
		               
		   // change statistics of gwes
		   changestat(1) = 0;     
           for(int k = 0; k< nrow; k++){
           if(   ( X(i,k) == 1 ) & ( X(j,k) == 1  )   ){
		   prei = sum( X.row(i)%X.row(k) );
   		   prej = sum( X.row(j)%X.row(k) );

   		   changestat(1) = changestat(1) + exp(decay)*geoweight(prei+1-1) ; 
		   if(prei >0){ changestat(1) = changestat(1) - exp(decay)*geoweight(prei-1);} 
 		   changestat(1) = changestat(1) + exp(decay)*geoweight(prej+1-1) ; 
		   if(prej >0){ changestat(1) = changestat(1) - exp(decay)*geoweight(prej-1);} 
           res = res + 1; // X(k,i) multiply X(i,j) +1 multiply X(j,k)
           }
           }
           if(res > 0){ changestat(1) = changestat(1) + exp(decay)*geoweight(res-1); }
     
		   // accept reject step  	       
		   // probability of Xij = 1 for given others are fixed 
           vec r =  exp(trans(coef)*changestat) ;         
           double p = r(0)/(1+r(0));   		   
		   if( randu() < p  ){
		   X(i,j) = X(j,i) = 1; 
		   star(i) = indi; star(j) = indj;		 
		   Sumstat = Sumstat + changestat;
		   }
		   
		   
		 // When Xij is 1  
         }else{
           indi = star(i) - 1, indj = star(j) - 1;	
		   // change statistics of edge
           changestat(0) = ( Choose(star(i),1) + Choose(star(j),1) - Choose(indi,1) - Choose(indj,1) )/2;
		   		   		        
           // change statistics of gwesp 
           changestat(1) = 0;
           for(int k = 0; k< nrow; k++){
           if(   ( X(i,k) == 1 ) & ( X(j,k) == 1  )   ){
		   prei = sum( X.row(i)%X.row(k) );
   		   prej = sum( X.row(j)%X.row(k) );
   		   if(prei-1 >0){changestat(1) = changestat(1) - exp(decay)*geoweight(prei-1-1); } 
			changestat(1) = changestat(1) + exp(decay)*geoweight(prei-1); 
 		   if(prej-1 >0){changestat(1) = changestat(1) - exp(decay)*geoweight(prej-1-1); } 
			changestat(1) = changestat(1) + exp(decay)*geoweight(prej-1); 
           res = res + 1; // X(k,i) multiply X(i,j)  multiply X(j,k)
           }
           }
           if(res > 0){ changestat(1) = changestat(1) + exp(decay)*geoweight(res-1); }
		   
		   // accept reject step  	       
		   // probability of Xij = 1 for given others are fixed 
           vec r =  exp(trans(coef)*changestat) ;         
           double p = r(0)/(1+r(0));   		   
		   if( randu() > p  ){
		   X(i,j) = X(j,i) = 0; 
		   star(i) = indi; star(j) = indj;  
		   Sumstat = Sumstat - changestat;
		   }             
         }
        // End of a single update  
        ivec(i) = 0; jvec(j) = 0;
    }
    }   
    }
 
return(X); 
}

// [[Rcpp::depends("RcppArmadillo")]]
// [[Rcpp::export]]
// Double metropolis hastings algorithm
mat ergmDMH(mat X, mat COV, mat theta, int outer, int cycle){
	
// Initializing part
double logprob,u;                          // used in Outer MCMC
int nCOVcols = COV.n_cols;                 // number of parameters	
vec thetaprev(nCOVcols);                   // before propose in Outer MCMC, previous parameters
vec stat = Summary(X), statprop(nCOVcols); // sufficient statistics
     	
//// Start of OUTER MCMC Chain 
for(int l = 0; l< outer; l++){

	if( (l > 1000) && (l <= 10000) ){ // adaptively update COV until 10000 iterations 
	COV = cov(theta);
    }	

    for(int i = 0; i< nCOVcols; i++){
    	thetaprev[i] = theta(l,i);
    }
    
    vec Znormal = randn(nCOVcols);                                           // multivariate proposal by using Cholesky factorization
    vec thetaprop = trans(  trans(thetaprev) + trans(Znormal)*chol(COV)  );  // proposed parameter

    // proposed auxiliary variable		
	statprop = Gibbs(X, thetaprop, cycle);
	
	// log probability ratio to determine acceptance of Outer MCMC 	   
	vec dummy = ( -0.05*trans(thetaprop)*thetaprop + 0.05*trans(thetaprev)*thetaprev + trans(thetaprev - thetaprop)*(statprop - stat) );
	logprob = dummy[0];
    u = log( randu() );
    if( u< logprob ){
    theta.insert_rows(l+1,trans(thetaprop));
	}else{
	theta.insert_rows(l+1,trans(thetaprev));
	}
		
}
	
return(theta);	
}


// [[Rcpp::depends("RcppArmadillo")]]
// [[Rcpp::export]]
// Generate summary statistics of auxiliary variables for given particles
cube pAuxSamp(mat X, int cycle, mat Designmat, int m, int num){

int thnrow = Designmat.n_rows;             // number of design points   
cube H(thnrow,2,m);                       // cube summary statistics will be stored. (thnrow by 2 by m)
omp_set_num_threads(num);


//////    START OF BIGGEST CHAIN (M)     ////// 
for(int M = 0; M < m; M++){               // m is number of importance sampling estimate 

        int i;
      #pragma omp parallel shared(Designmat) private(i)
      {	
      #pragma omp for schedule(static)  
    for(i = 0; i < thnrow; i++){
        vec thetaprop = trans( Designmat.row( i ) );        
        vec sumstat = Gibbs(X, thetaprop, cycle);
		
	for(int j = 0; j < 2; j++){ H(i,j,M) = sumstat[j];  }
		 	
        }
     }
}
return(H);        	
}

// [[Rcpp::depends("RcppArmadillo")]]
// [[Rcpp::export]]
// Generate summary statistics of auxiliary variables for given particles to construct IS estimate

mat pResponse(mat X, int cycle, vec hatparameter, int m, int num){

mat H(m,2);                         // matrix where summary statistics will be stored. (m by 2)
omp_set_num_threads(num);

//////    START OF BIGGEST CHAIN (M)     ////// 
int M;
#pragma omp parallel shared(H) private(M)
{	
#pragma omp for schedule(static)  
for(M = 0; M < m; M++){                            // m is number of importance sampling estimate 
   
    vec sumstat = Gibbs(X, hatparameter, cycle);   // summary statistics
    H(M,0) = sumstat[0];
    H(M,1) = sumstat[1];
}
}

return(H);        	
}



// [[Rcpp::depends("RcppArmadillo")]]
// [[Rcpp::export]]
// GPMCMC for Ergm
mat GPmcmc(int Niter, mat theta, mat COV, double lhXZ, vec betahat, vec phihat, mat Designmat, vec y, vec stat){
	int thnrow = Designmat.n_rows;                                                 // number of design points
	int nCOVcols = COV.n_cols;                                                     // number of parameters
	vec thetaprev(nCOVcols);                                                       // befor propose in MCMC, previous parameters
	
	double lhXZp,logprob,u;                                               // used in MCMC step
	double negativeInf = -std::numeric_limits<float>::infinity();;	               
	double phi1hat = phihat[0], phi2hat = phihat[1], sigmasqhat = phihat[2]; 
	
	// percentile is same as 1 when 400 design points
	int percentile = 0.0025*thnrow; 
	
	// boundary from design points
	mat Domain(2,nCOVcols);                                                         
	for(int i = 0; i < nCOVcols; i++){
	vec dummy = sort( Designmat.col( i ) );
	Domain(0,i) = dummy(percentile);
	Domain(1,i) = dummy(thnrow-1-percentile);
    }
	
	mat h1(thnrow,thnrow), h2(thnrow,thnrow);   // used to construct Sigma in Gaussian process
    vec h1dcross(thnrow), h2dcross(thnrow);     // used to construct cross Sigma in Gaussian process
    
    for(int i = 0; i < thnrow; i++){
        for(int j = 0; j <= i; j++){
	        h1(i,j) = h1(j,i) = fabs(Designmat(i,0)-Designmat(j,0));
	        h2(i,j) = h2(j,i) = fabs(Designmat(i,1)-Designmat(j,1));
	    }
	}
	mat Sigma = sigmasqhat*(1+sqrt(3)*h1/phi1hat)%exp(-sqrt(3)*h1/phi1hat)%(1+sqrt(3)*h2/phi2hat)%exp(-sqrt(3)*h2/phi2hat);
	mat InvSigma = inv(Sigma);	    // Inverse of Sigma in Gaussian process
	mat Xth = ones(thnrow,1);
    Xth.insert_cols(1,Designmat);	// make design matrix for linear model 
	
	
	 // Start of MCMC Chain 
	for(int k = 0; k< Niter; k++){
	    if( (k > 1000) && (k <= 10000) ){ // adaptively update COV until 10000 iterations 
	    COV = cov(theta);
        }	
        vec Znormal = randn(nCOVcols); // multivariate proposal by using Cholesky factorization
    	for(int i = 0; i< nCOVcols; i++){
    		thetaprev[i] = theta(k,i);
		}
		
		// proposed parameter and corresponding rho coefficients
    	vec thetaprop = trans(  trans(thetaprev) + trans(Znormal)*chol(COV)  );
     
	    // constranits on prior space
        if( thetaprop[0] > Domain(1,0) || thetaprop[0] < Domain(0,0) || thetaprop[1] > Domain(1,1) || thetaprop[1] < Domain(0,1) ){
		logprob = negativeInf;	
		
		}else{			
		for(int i = 0; i< thnrow; i++){  // Caculating cross covaraince matrix
    		h1dcross[i] =  fabs(thetaprop[0]-Designmat(i,0));
			h2dcross[i] =  fabs(thetaprop[1]-Designmat(i,1));	
		}
    	mat Sigmacross = sigmasqhat*(1+sqrt(3)*h1dcross/phi1hat)%exp(-sqrt(3)*h1dcross/phi1hat)%(1+sqrt(3)*h2dcross/phi2hat)%exp(-sqrt(3)*h2dcross/phi2hat);
    	vec xpoint = ones(1);
    	xpoint.insert_rows(1,thetaprop);
    	lhXZp = (trans(xpoint)*betahat + trans(Sigmacross)* InvSigma*(y-Xth*betahat))[0]; //Gaussian kriging for intractable term
    
    	logprob = lhXZp - lhXZ;              // log probability ratio to determine acceptance of MCMC 
        } 

        u = log( randu() );
    	if( u< logprob ){
    	theta.insert_rows(k+1,trans(thetaprop));
		lhXZ = lhXZp;		
		}else{
	    theta.insert_rows(k+1,trans(thetaprev));
		}

   }
		
return theta;
}



